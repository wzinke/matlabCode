/*  Mergesort.h

    Sort an array of structs

    Brendan Hasz
    haszx010@umn.edu
    Feb 2015
    David Redish Lab
    University of Minnesota, Twin Cities
*/

void MergeSort(struct ALG_EDGE *, int);

