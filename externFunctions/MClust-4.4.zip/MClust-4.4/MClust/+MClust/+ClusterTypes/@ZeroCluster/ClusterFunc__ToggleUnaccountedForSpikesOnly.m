function ClusterFunc__ToggleUnaccountedForSpikesOnly( self )
% ShowUnaccountedForSpikesOnly
% remove all points from the cluster

%================================================
% PARAMETERS
%================================================
%================================================
% MAIN CODE
%================================================

self.ChangeShowUnaccountedForOnly();