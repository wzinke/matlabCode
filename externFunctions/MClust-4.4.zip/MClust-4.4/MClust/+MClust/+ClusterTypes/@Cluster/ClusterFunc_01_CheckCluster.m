function ClusterFunc_01_CheckCluster(self)

% f = DeleteCluster()
%
% ncst 26 Nov 02
% ADR 2008
%

self.CheckCluster();