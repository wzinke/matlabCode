function VERSION = MClustVersion()

VERSION = 'MClust 4.4.05; 2016/Jul/28';

